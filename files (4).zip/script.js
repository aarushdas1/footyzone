/* ===== 1. SAMPLE DATA (all fictional/sample, edit freely) ===== */
const POS = {GK:"Goalkeeper",CB:"Centre-Back",LB:"Left-Back",RB:"Right-Back",CDM:"Defensive Midfielder",CM:"Central Midfielder",CAM:"Attacking Midfielder",LW:"Left Winger",RW:"Right Winger",ST:"Striker"};
const LEAGUES = ["Premier League","La Liga","Serie A","Bundesliga","Ligue 1"];
// ucl:true = regular Champions League club (sample, changes every season)
const SAMPLE_CLUBS = [
  {id:"mci",name:"Manchester City",short:"MCI",color:"#6cabdd",league:"Premier League",city:"Manchester",stadium:"Etihad Stadium",founded:1880,ucl:true},
  {id:"ars",name:"Arsenal",short:"ARS",color:"#ef0107",league:"Premier League",city:"London",stadium:"Emirates Stadium",founded:1886,ucl:true},
  {id:"liv",name:"Liverpool",short:"LIV",color:"#c8102e",league:"Premier League",city:"Liverpool",stadium:"Anfield",founded:1892,ucl:true},
  {id:"che",name:"Chelsea",short:"CHE",color:"#034694",league:"Premier League",city:"London",stadium:"Stamford Bridge",founded:1905,ucl:true},
  {id:"mun",name:"Manchester United",short:"MUN",color:"#da291c",league:"Premier League",city:"Manchester",stadium:"Old Trafford",founded:1878},
  {id:"rma",name:"Real Madrid",short:"RMA",color:"#7a5cff",league:"La Liga",city:"Madrid",stadium:"Santiago Bernabéu",founded:1902,ucl:true},
  {id:"bar",name:"Barcelona",short:"BAR",color:"#a50044",league:"La Liga",city:"Barcelona",stadium:"Camp Nou",founded:1899,ucl:true},
  {id:"atm",name:"Atlético Madrid",short:"ATM",color:"#cb3524",league:"La Liga",city:"Madrid",stadium:"Metropolitano",founded:1903,ucl:true},
  {id:"int",name:"Inter Milan",short:"INT",color:"#0a3d91",league:"Serie A",city:"Milan",stadium:"San Siro",founded:1908,ucl:true},
  {id:"mil",name:"AC Milan",short:"MIL",color:"#fb090b",league:"Serie A",city:"Milan",stadium:"San Siro",founded:1899},
  {id:"juv",name:"Juventus",short:"JUV",color:"#444",league:"Serie A",city:"Turin",stadium:"Allianz Stadium",founded:1897},
  {id:"nap",name:"Napoli",short:"NAP",color:"#12a0d7",league:"Serie A",city:"Naples",stadium:"Stadio Diego Armando Maradona",founded:1926,ucl:true},
  {id:"bay",name:"Bayern Munich",short:"BAY",color:"#dc052d",league:"Bundesliga",city:"Munich",stadium:"Allianz Arena",founded:1900,ucl:true},
  {id:"bvb",name:"Borussia Dortmund",short:"BVB",color:"#e0a800",league:"Bundesliga",city:"Dortmund",stadium:"Signal Iduna Park",founded:1909,ucl:true},
  {id:"lev",name:"Bayer Leverkusen",short:"B04",color:"#e32221",league:"Bundesliga",city:"Leverkusen",stadium:"BayArena",founded:1904,ucl:true},
  {id:"psg",name:"Paris Saint-Germain",short:"PSG",color:"#004170",league:"Ligue 1",city:"Paris",stadium:"Parc des Princes",founded:1970,ucl:true},
  {id:"mar",name:"Marseille",short:"OM",color:"#2faee0",league:"Ligue 1",city:"Marseille",stadium:"Stade Vélodrome",founded:1899},
  {id:"mon",name:"AS Monaco",short:"MON",color:"#e51b24",league:"Ligue 1",city:"Monaco",stadium:"Stade Louis II",founded:1924}
];
// [name, club id, position code, nationality, goals, assists]  (stats are SAMPLE numbers)
// Check transfers: squads change every window, edit this list to keep it current.
const SAMPLE_PLAYERS = [
  ["Erling Haaland","mci","ST","Norway",18,4],["Phil Foden","mci","CAM","England",7,6],["Rodri","mci","CDM","Spain",4,5],
  ["Bukayo Saka","ars","RW","England",10,9],["Declan Rice","ars","CM","England",5,8],["William Saliba","ars","CB","France",2,1],["Martin Ødegaard","ars","CAM","Norway",6,8],["David Raya","ars","GK","Spain",0,0],
  ["Mohamed Salah","liv","RW","Egypt",14,12],["Virgil van Dijk","liv","CB","Netherlands",3,1],["Alisson","liv","GK","Brazil",0,0],["Florian Wirtz","liv","CAM","Germany",6,9],["Alexander Isak","liv","ST","Sweden",11,3],
  ["Cole Palmer","che","CAM","England",12,10],["Enzo Fernández","che","CM","Argentina",5,6],["Bruno Fernandes","mun","CAM","Portugal",8,11],
  ["Kylian Mbappé","rma","ST","France",16,6],["Vinícius Júnior","rma","LW","Brazil",11,8],["Jude Bellingham","rma","CAM","England",8,7],["Trent Alexander-Arnold","rma","RB","England",2,9],["Antonio Rüdiger","rma","CB","Germany",2,0],["Thibaut Courtois","rma","GK","Belgium",0,0],["Federico Valverde","rma","CM","Uruguay",4,5],
  ["Lamine Yamal","bar","RW","Spain",9,11],["Raphinha","bar","LW","Brazil",10,9],["Robert Lewandowski","bar","ST","Poland",13,3],["Pedri","bar","CM","Spain",4,7],["Jules Koundé","bar","RB","France",1,4],
  ["Julián Álvarez","atm","ST","Argentina",12,5],
  ["Lautaro Martínez","int","ST","Argentina",15,4],["Nicolò Barella","int","CM","Italy",4,6],["Alessandro Bastoni","int","CB","Italy",2,4],["Federico Dimarco","int","LB","Italy",3,9],
  ["Rafael Leão","mil","LW","Portugal",9,7],["Mike Maignan","mil","GK","France",0,0],["Kenan Yıldız","juv","LW","Turkey",8,6],
  ["Kevin De Bruyne","nap","CAM","Belgium",5,10],["Scott McTominay","nap","CM","Scotland",7,3],
  ["Harry Kane","bay","ST","England",20,8],["Jamal Musiala","bay","CAM","Germany",9,8],["Michael Olise","bay","RW","France",8,10],["Joshua Kimmich","bay","CDM","Germany",2,9],["Manuel Neuer","bay","GK","Germany",0,0],
  ["Serhou Guirassy","bvb","ST","Guinea",14,3],
  ["Ousmane Dembélé","psg","RW","France",13,7],["Désiré Doué","psg","RW","France",7,6],["Vitinha","psg","CM","Portugal",4,6],["Achraf Hakimi","psg","RB","Morocco",5,8],
  ["Mason Greenwood","mar","RW","England",11,6]
].map(([name,club,pos,nat,goals,assists]) => ({name,club,pos,nat,goals,assists}));
// If data.js (made with tools/convert.html) exists, use it. Otherwise use the sample data above.
const clubs = (window.FZ && FZ.clubs) || SAMPLE_CLUBS;
const players = (window.FZ && FZ.players) || SAMPLE_PLAYERS;
if (window.FZ) document.querySelector(".notice").innerHTML = "ℹ️ Player data: " + FZ.source + ". Ratings are game ratings, not real match statistics. Scores, fixtures, news and the table are <b>sample/fictional data</b>.";
const news = [
  {t:"Title race heats up as leaders edge a thriller",c:"Premier League",e:"🏆",g:"#00e676,#00b0ff"},
  {t:"Champions League draw sets up a blockbuster tie",c:"Champions League",e:"🌟",g:"#00b0ff,#7a5cff"},
  {t:"El Clásico preview: what to expect in Madrid",c:"La Liga",e:"🔥",g:"#ff9100,#ef0107"},
  {t:"Young striker breaks scoring record for his country",c:"International",e:"🌍",g:"#00e676,#ff9100"},
  {t:"Manager praises squad depth after cup win",c:"Premier League",e:"👏",g:"#ff9100,#00b0ff"},
  {t:"Underdogs stun giants in European night of drama",c:"Champions League",e:"⚡",g:"#7a5cff,#00e676"},
  {t:"Teenage winger tipped as La Liga's next star",c:"La Liga",e:"✨",g:"#a50044,#ff9100"},
  {t:"Qualifiers: group leaders confirmed this week",c:"International",e:"🥇",g:"#00b0ff,#00e676"}
];
const matches = [
  {h:"ars",a:"liv",hs:2,as:1,st:"FT",date:"Sat 15:00",ven:"Emirates Stadium",ev:"Saka 23', Kane-style header 67' (fictional)"},
  {h:"mci",a:"che",hs:3,as:3,st:"FT",date:"Sat 17:30",ven:"Etihad Stadium",ev:"Six-goal thriller (fictional)"},
  {h:"rma",a:"bar",hs:null,as:null,st:"Upcoming",date:"Sun 20:00",ven:"Santiago Bernabéu",ev:"El Clásico. Kick-off 20:00 (fictional fixture)"},
  {h:"bay",a:"psg",hs:1,as:2,st:"FT",date:"Tue 20:00",ven:"Allianz Arena",ev:"Late winner in stoppage time (fictional)"},
  {h:"liv",a:"mci",hs:null,as:null,st:"Upcoming",date:"Next Sat",ven:"Anfield",ev:"Top-of-the-table clash (fictional fixture)"},
  {h:"che",a:"ars",hs:0,as:0,st:"FT",date:"Last Sun",ven:"Stamford Bridge",ev:"Goalless London derby (fictional)"}
];
// [name, W, D, L, GF, GA] after 12 sample games each
const league = [["Arsenal",9,2,1,24,8],["Manchester City",8,2,2,27,11],["Liverpool",8,1,3,22,12],["Chelsea",7,3,2,21,12],["Aston Villa",7,2,3,19,13],["Tottenham",6,3,3,20,15],["Newcastle",6,3,3,18,13],["Manchester United",6,2,4,17,15],["Brighton",5,4,3,18,16],["West Ham",5,3,4,16,17],["Brentford",5,2,5,17,17],["Fulham",4,4,4,14,15],["Crystal Palace",4,4,4,13,14],["Everton",4,3,5,12,15],["Wolves",4,2,6,13,19],["Bournemouth",3,4,5,13,18],["Nottm Forest",3,3,6,11,18],["Leicester",2,4,6,12,22],["Ipswich",2,3,7,10,21],["Southampton",1,3,8,8,24]]
  .map(([name,w,d,l,gf,ga])=>({name,p:w+d+l,w,d,l,gf,ga,gd:gf-ga,pts:w*3+d}));

/* ===== 2. HELPERS ===== */
const $ = id => document.getElementById(id);
const clubById = id => clubs.find(c => c.id === id) || SAMPLE_CLUBS.find(c => c.id === id);
const slug = n => n.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/ø/g, "o").replace(/ı/g, "i").replace(/ł/g, "l").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
// Puts an image on top of the badge. If the file doesn't exist, the image removes itself and the initials stay.
const img = (folder, file, ext, cls) => `<img class="${cls}" src="assets/images/${folder}/${file}.${ext}" alt="" loading="lazy" onload="this.parentNode.classList.add('has-img')" onerror="this.remove()">`;
const badge = (c, sm) => `<span class="badge ${sm ? "sm" : ""}" style="background:${c.color}" title="logo file: ${c.id}.png"><b class="t">${c.short}</b>${img("clubs", c.id, "png", "logo-img")}</span>`;
const initials = n => n.split(" ").map(w => w[0]).slice(0, 2).join("");
let favs = [];
try { favs = JSON.parse(localStorage.getItem("fz-favs")) || []; } catch (e) {}

/* ===== 3. NEWS ===== */
const cats = ["All", "Premier League", "Champions League", "La Liga", "International"];
let newsCat = "All";
const newsCard = n => `<article class="card"><div class="news-img" style="background:linear-gradient(135deg,${n.g})">${n.e}</div><span class="tag">${n.c}</span><h3>${n.t}</h3><p class="muted">Sample headline</p></article>`;
function renderNews() {
  $("newsTabs").innerHTML = cats.map(c => `<button class="btn ${c === newsCat ? "on" : "ghost"}" data-cat="${c}">${c}</button>`).join("");
  $("newsGrid").innerHTML = news.filter(n => newsCat === "All" || n.c === newsCat).map(newsCard).join("");
}
$("newsTabs").addEventListener("click", e => { if (e.target.dataset.cat) { newsCat = e.target.dataset.cat; renderNews(); } });

/* ===== 4. PLAYERS (search + filters + favourites) ===== */
let favOnly = false, shown = 24; // shown = how many player cards are visible
$("posFilter").innerHTML = `<option value="All">All positions</option>` + Object.entries(POS).map(([k, v]) => `<option value="${k}">${v}</option>`).join("");
$("leagueFilter").innerHTML = `<option value="All">All leagues</option>` + LEAGUES.map(l => `<option>${l}</option>`).join("") + (clubs.some(c => c.ucl) ? `<option value="UCL">Champions League clubs</option>` : "");
$("clubFilter").innerHTML = `<option value="All">All clubs</option>` + clubs.map(c => `<option value="${c.id}">${c.name}</option>`).join("");
function renderPlayers() {
  const q = $("globalSearch").value.toLowerCase().trim();
  const pos = $("posFilter").value, club = $("clubFilter").value, lg = $("leagueFilter").value;
  const list = players.filter(p => {
    const c = clubById(p.club);
    return (!q || (p.name + c.name + p.nat + POS[p.pos]).toLowerCase().includes(q)) &&
      (pos === "All" || p.pos === pos) && (club === "All" || p.club === club) &&
      (lg === "All" || (lg === "UCL" ? c.ucl : c.league === lg)) && (!favOnly || favs.includes(p.name));
  });
  $("playerGrid").innerHTML = list.length ? list.slice(0, shown).map(p => {
    const c = clubById(p.club), f = favs.includes(p.name), s = slug(p.name);
    return `<article class="card player"><button class="fav" data-name="${p.name}" aria-label="Favourite ${p.name}">${f ? "♥" : "♡"}</button>
      <span class="badge" style="background:${c.color}" title="photo file: ${s}.jpg"><b class="t">${initials(p.name)}</b>${p.photo ? `<img class="photo" src="${p.photo}" alt="" loading="lazy" onload="this.parentNode.classList.add('has-img')" onerror="this.remove()">` : img("players", s, "jpg", "photo")}</span><h3>${p.name}</h3>
      <p class="muted">${POS[p.pos]} · ${p.nat}</p><p>${c.name}</p>
      ${p.goals != null ? `<div class="stats"><div><b>${p.goals}</b>Goals</div><div><b>${p.assists}</b>Assists</div></div>` : `<div class="stats"><div><b>${p.ovr}</b>Rating</div><div><b>${p.age}</b>Age</div></div>`}</article>`;
  }).join("") + (list.length > shown ? `<div class="empty"><p>Showing ${shown} of ${list.length} players</p><button class="btn" id="moreBtn">Show more</button></div>` : "") : `<p class="empty">No players found. Try another search or filter.</p>`;
}
$("playerGrid").addEventListener("click", e => {
  if (e.target.id === "moreBtn") { shown += 24; renderPlayers(); return; }
  const n = e.target.dataset.name; if (!n) return;
  favs = favs.includes(n) ? favs.filter(x => x !== n) : [...favs, n];
  try { localStorage.setItem("fz-favs", JSON.stringify(favs)); } catch (err) {}
  renderPlayers();
});
["posFilter", "clubFilter", "leagueFilter"].forEach(id => $(id).addEventListener("change", () => { shown = 24; renderPlayers(); }));
$("globalSearch").addEventListener("input", () => {
  shown = 24; renderPlayers();
  if ($("globalSearch").value) $("players").scrollIntoView();
});
$("favOnly").addEventListener("click", e => {
  favOnly = !favOnly; e.target.classList.toggle("on", favOnly);
  e.target.textContent = favOnly ? "♥ Favourites only" : "♡ Favourites only";
  renderPlayers();
});

/* ===== 5. CLUBS (click for details) ===== */
const clubCard = c => `<article class="card club" data-club="${c.id}" tabindex="0">${badge(c)}<h3>${c.name}</h3><p class="muted">${c.league}</p></article>`;
let clubTab = "All";
const clubTabs = ["All", ...LEAGUES, ...(clubs.some(c => c.ucl) ? ["Champions League"] : [])];
function renderClubs() {
  $("clubTabs").innerHTML = clubTabs.map(t => `<button class="btn ${t === clubTab ? "on" : "ghost"}" data-tab="${t}">${t}</button>`).join("");
  $("clubGrid").innerHTML = clubs.filter(c => clubTab === "All" || (clubTab === "Champions League" ? c.ucl : c.league === clubTab)).map(clubCard).join("");
}
$("clubTabs").addEventListener("click", e => { if (e.target.dataset.tab) { clubTab = e.target.dataset.tab; renderClubs(); } });
$("trendingGrid").innerHTML = clubs.slice(0, 4).map(clubCard).join("");
function openClub(id) {
  const c = clubById(id), sq = players.filter(p => p.club === id).sort((a, b) => Object.keys(POS).indexOf(a.pos) - Object.keys(POS).indexOf(b.pos));
  $("modalBody").innerHTML = `<div style="display:flex;gap:1rem;align-items:center">${badge(c)}<div><h2>${c.name}</h2><p class="muted">${c.league}</p></div></div>
    <p style="margin:1rem 0">${[c.city && "📍 " + c.city, c.stadium && "🏟️ " + c.stadium, c.founded && "📅 Founded " + c.founded].filter(Boolean).join(" · ") || c.league}</p>
    <h3>Squad (${sq.length} players)</h3><ul>${sq.length ? sq.map(p => `<li>${p.name} · ${POS[p.pos]}${p.goals != null ? " · " + p.goals + " goals, " + p.assists + " assists" : " · rating " + p.ovr}</li>`).join("") : "<li>No players listed.</li>"}</ul>`;
  $("modal").hidden = false;
}
document.addEventListener("click", e => { const c = e.target.closest("[data-club]"); if (c) openClub(c.dataset.club); });
document.addEventListener("keydown", e => {
  if (e.key === "Enter" && e.target.dataset.club) openClub(e.target.dataset.club);
  if (e.key === "Escape") $("modal").hidden = true;
});
$("closeModal").onclick = () => $("modal").hidden = true;
$("modal").addEventListener("click", e => { if (e.target.id === "modal") $("modal").hidden = true; });

/* ===== 6. MATCHES ===== */
const matchCard = m => {
  const h = clubById(m.h), a = clubById(m.a);
  return `<article class="card match" tabindex="0"><p class="muted">${m.date} · <span class="${m.st === "FT" ? "" : "live"}">${m.st}</span></p>
    <div class="row"><div>${badge(h, 1)}<br>${h.short}</div><div class="score">${m.hs === null ? "vs" : m.hs + " - " + m.as}</div><div>${badge(a, 1)}<br>${a.short}</div></div>
    <button class="btn ghost" data-more>Match details</button>
    <div class="more">🏟️ ${m.ven}<br>${m.ev}</div></article>`;
};
$("matchGrid").innerHTML = matches.map(matchCard).join("");
$("featuredGrid").innerHTML = matches.slice(0, 3).map(matchCard).join("");
document.addEventListener("click", e => { if (e.target.dataset.more !== undefined) e.target.closest(".match").classList.toggle("open"); });

/* ===== 7. LEAGUE TABLE ===== */
let sortKey = "pts";
function renderTable() {
  const rows = [...league].sort((a, b) => b[sortKey] - a[sortKey] || b.gd - a.gd || b.gf - a.gf);
  $("table").querySelector("tbody").innerHTML = rows.map((t, i) => {
    const cls = sortKey !== "pts" ? "" : i < 4 ? "ucl" : i < 6 ? "uel" : i >= league.length - 3 ? "rel" : "";
    return `<tr class="${cls}"><td>${i + 1}</td><td>${t.name}</td><td>${t.p}</td><td>${t.w}</td><td>${t.d}</td><td>${t.l}</td><td>${t.gf}</td><td>${t.ga}</td><td>${t.gd > 0 ? "+" : ""}${t.gd}</td><td>${t.pts}</td></tr>`;
  }).join("");
}
$("table").querySelector("thead").addEventListener("click", e => { if (e.target.dataset.k) { sortKey = e.target.dataset.k; renderTable(); } });

/* ===== 8. HEADLINES, THEME, MOBILE MENU, LOADER ===== */
$("headlineGrid").innerHTML = news.slice(0, 3).map(newsCard).join("");
const setTheme = t => { document.documentElement.dataset.theme = t; $("themeBtn").textContent = t === "dark" ? "🌙" : "☀️"; try { localStorage.setItem("fz-theme", t); } catch (e) {} };
let saved = "dark"; try { saved = localStorage.getItem("fz-theme") || "dark"; } catch (e) {}
setTheme(saved);
$("themeBtn").onclick = () => setTheme(document.documentElement.dataset.theme === "dark" ? "light" : "dark");
$("menuBtn").onclick = () => $("nav").classList.toggle("open");
$("nav").addEventListener("click", () => $("nav").classList.remove("open"));
renderNews(); renderPlayers(); renderClubs(); renderTable();
window.addEventListener("load", () => setTimeout(() => $("loader").classList.add("done"), 900));
