// Turns a free player CSV (e.g. an EA FC / FIFA dataset from Kaggle) into data.js for FOOTYZONE.
const LEAGUE_RULES = [
  ["Premier League", /^(english )?premier league\b(?!\s*2)/],
  ["La Liga", /^(la ?liga( ea sports)?|spain primera division|primera division)\b/],
  ["Serie A", /^(italian )?serie a\b/],
  ["Bundesliga", /^(german )?(1\. )?bundesliga\b(?!\s*2)/],
  ["Ligue 1", /^(french )?ligue 1\b/]
];
const POS_MAP = {GK:"GK",CB:"CB",LB:"LB",LWB:"LB",RB:"RB",RWB:"RB",CDM:"CDM",DM:"CDM",CM:"CM",CAM:"CAM",AM:"CAM",LM:"LW",LW:"LW",RM:"RW",RW:"RW",CF:"ST",ST:"ST",SS:"ST",
  GOALKEEPER:"GK",DEFENDER:"CB",MIDFIELDER:"CM",FORWARD:"ST",ATTACKER:"ST"};
const ALIASES = {
  name:["name","long_name","player_name","player","short_name"], club:["club","club_name","team"],
  league:["league","league_name","club_league"], pos:["positions","player_positions","position","best_position"],
  nat:["nationality","nationality_name","nation"], ovr:["overall","ovr","overall_rating"], age:["age"],
  photo:["player_face_url","photo","image","face_url"], version:["fifa_version","version","year","season"]
};
function parseCSV(t) {
  const rows = []; let r = [], f = "", q = false;
  for (let i = 0; i < t.length; i++) {
    const ch = t[i];
    if (q) { if (ch === '"') { if (t[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += ch; }
    else if (ch === '"') q = true;
    else if (ch === ",") { r.push(f); f = ""; }
    else if (ch === "\n") { r.push(f); rows.push(r); r = []; f = ""; }
    else if (ch !== "\r") f += ch;
  }
  if (f || r.length) { r.push(f); rows.push(r); }
  return rows;
}
const slug = n => n.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/ø/g, "o").replace(/ı/g, "i").replace(/ł/g, "l").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
function buildData(text, withPhotos) {
  const rows = parseCSV(text), head = rows[0].map(h => h.trim().toLowerCase());
  const col = {}; for (const k in ALIASES) { const i = ALIASES[k].map(a => head.indexOf(a)).find(i => i >= 0); col[k] = i === undefined ? -1 : i; }
  for (const k of ["name", "club", "league", "pos"]) if (col[k] < 0) throw new Error("Could not find a '" + k + "' column. Columns found: " + head.join(", "));
  let data = rows.slice(1).filter(r => r.length > col.name);
  if (col.version >= 0) { const top = Math.max(...data.map(r => +r[col.version] || 0)); if (top) data = data.filter(r => +r[col.version] === top); }
  const unmatched = {}, seen = new Set(), clubMap = {}, players = [];
  for (const r of data) {
    const lg = LEAGUE_RULES.find(([, re]) => re.test((r[col.league] || "").trim().toLowerCase()));
    if (!lg) { const k = r[col.league]; unmatched[k] = (unmatched[k] || 0) + 1; continue; }
    const club = r[col.club].trim(), name = r[col.name].trim(), key = name + "|" + club;
    if (!club || !name || seen.has(key)) continue; seen.add(key);
    const first = r[col.pos].split(/[,\s]+/)[0].toUpperCase(), pos = POS_MAP[first];
    if (!pos) continue;
    const id = slug(club);
    const c = clubMap[id] || (clubMap[id] = {id, name: club, short: club.replace(/[^A-Za-z]/g, "").slice(0, 3).toUpperCase(), color: "hsl(" + (club.split("").reduce((a, ch) => a * 31 + ch.charCodeAt(0), 7) % 360) + ",55%,38%)", league: lg[0], sum: 0, n: 0});
    const p = {name, club: id, pos, nat: (r[col.nat] || "").trim(), ovr: +r[col.ovr] || 0, age: +r[col.age] || 0};
    if (withPhotos && col.photo >= 0 && /^https?:/.test(r[col.photo])) p.photo = r[col.photo].trim();
    c.sum += p.ovr; c.n++; players.push(p);
  }
  const clubs = Object.values(clubMap).sort((a, b) => b.sum / b.n - a.sum / a.n).map(({sum, n, ...c}) => c);
  const counts = {}; clubs.forEach(c => counts[c.league] = (counts[c.league] || 0) + 1);
  const top = Object.entries(unmatched).sort((a, b) => b[1] - a[1]).slice(0, 12);
  return {clubs, players, counts, unmatched: top};
}
if (typeof module !== "undefined") module.exports = {buildData};
